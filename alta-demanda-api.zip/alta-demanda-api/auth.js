const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { db } = require('./database');

const SECRET = 'segredo-super-secreto-mude-em-producao';

function registrar(username, password, callback) {
  const hashedPassword = bcrypt.hashSync(password, 10);
  
  db.run(`
    INSERT INTO usuarios (username, password) 
    VALUES (?, ?)
  `, [username, hashedPassword], function(err) {
    if (err) {
      return callback({ error: 'USUARIO_JA_EXISTE' });
    }
    
    // Inicializa cota do usuário
    db.run(`
      INSERT INTO cota_usuario (usuario_id, vagas_ativas) 
      VALUES (?, 0)
    `, [this.lastID]);
    
    callback(null, { id: this.lastID, username });
  });
}

function login(username, password, callback) {
  db.get(`
    SELECT id, username, password FROM usuarios WHERE username = ?
  `, [username], (err, user) => {
    if (err || !user || !bcrypt.compareSync(password, user.password)) {
      return callback({ error: 'CREDENCIAIS_INVALIDAS' });
    }
    
    const token = jwt.sign({ id: user.id, username: user.username }, SECRET, { expiresIn: '24h' });
    callback(null, { token });
  });
}

function verificarToken(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'TOKEN_NAO_FORNECIDO' });
  }
  
  const token = authHeader.split(' ')[1];
  
  try {
    const decoded = jwt.verify(token, SECRET);
    req.usuarioId = decoded.id;
    req.usuarioNome = decoded.username;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'TOKEN_INVALIDO' });
  }
}

module.exports = { registrar, login, verificarToken };