const express = require('express');
const { db, submeterEntidade, finalizarEntidade } = require('./database');
const { registrar, login, verificarToken } = require('./auth');

const app = express();
app.use(express.json());

// Rota de registro
app.post('/auth/registrar', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'USERNAME_E_PASSWORD_OBRIGATORIOS' });
  }
  
  registrar(username, password, (err, result) => {
    if (err) return res.status(409).json(err);
    res.status(201).json(result);
  });
});

// Rota de login
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;
  
  login(username, password, (err, result) => {
    if (err) return res.status(401).json(err);
    res.status(200).json(result);
  });
});

// Criar entidade (rascunho)
app.post('/entidades', verificarToken, (req, res) => {
  const { produtoId } = req.body; // tema e-commerce
  
  db.run(`
    INSERT INTO entidades (usuario_id, produto_id, status) 
    VALUES (?, ?, 'RASCUNHO')
  `, [req.usuarioId, produtoId || 12], function(err) {
    if (err) {
      return res.status(500).json({ error: 'ERRO_CRIAR_ENTIDADE' });
    }
    
    res.status(201).json({ id: this.lastID, status: 'RASCUNHO' });
  });
});

// Submeter (disputado - aqui está o segredo)
app.post('/entidades/:id/submeter', verificarToken, (req, res) => {
  const entidadeId = parseInt(req.params.id);
  const usuarioId = req.usuarioId;
  
  submeterEntidade(entidadeId, usuarioId, (err, result) => {
    if (err) {
      if (err.error === 'POOL_CHEIO') return res.status(409).json({ error: 'POOL_CHEIO' });
      if (err.error === 'COTA_PESSOAL') return res.status(409).json({ error: 'COTA_PESSOAL' });
      return res.status(404).json({ error: 'ENTIDADE_NAO_ENCONTRADA' });
    }
    
    res.status(200).json(result);
  });
});

// Finalizar (devolve vaga)
app.post('/entidades/:id/finalizar', verificarToken, (req, res) => {
  const entidadeId = parseInt(req.params.id);
  const usuarioId = req.usuarioId;
  
  finalizarEntidade(entidadeId, usuarioId, (err, result) => {
    if (err) {
      return res.status(404).json({ error: 'ENTIDADE_NAO_ENCONTRADA' });
    }
    
    res.status(200).json(result);
  });
});

// Rota para consultar status do pool (útil para testes)
app.get('/admin/pool', verificarToken, (req, res) => {
  db.get(`SELECT vagas_restantes FROM pool_global WHERE id = 1`, (err, row) => {
    res.json({ vagas_restantes: row?.vagas_restantes || 0 });
  });
});

// Rota para ver cota do usuário
app.get('/admin/minha-cota', verificarToken, (req, res) => {
  db.get(`
    SELECT vagas_ativas FROM cota_usuario WHERE usuario_id = ?
  `, [req.usuarioId], (err, row) => {
    res.json({ vagas_ativas: row?.vagas_ativas || 0 });
  });
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`🚀 API rodando em http://localhost:${PORT}`);
});