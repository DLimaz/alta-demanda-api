const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Usa uma pasta que o container tem permissão de escrita
const dbPath = process.env.NODE_ENV === 'production' 
  ? '/app/data/database.db'  // dentro do container
  : path.join(__dirname, 'database.db');  // localmente

const fs = require('fs');
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new sqlite3.Database(dbPath);

// Inicializa as tabelas
db.serialize(() => {
  // Tabela de usuários
  db.run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT
    )
  `);

  // Tabela de entidades (rascunhos)
  db.run(`
    CREATE TABLE IF NOT EXISTS entidades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      produto_id INTEGER,
      status TEXT DEFAULT 'RASCUNHO',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    )
  `);

  // Tabela do pool global (única linha com as 100 vagas)
  db.run(`
    CREATE TABLE IF NOT EXISTS pool_global (
      id INTEGER PRIMARY KEY DEFAULT 1,
      vagas_restantes INTEGER NOT NULL CHECK (vagas_restantes >= 0)
    )
  `);

  // Tabela de cota pessoal
  db.run(`
    CREATE TABLE IF NOT EXISTS cota_usuario (
      usuario_id INTEGER PRIMARY KEY,
      vagas_ativas INTEGER NOT NULL DEFAULT 0 CHECK (vagas_ativas BETWEEN 0 AND 2),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    )
  `);

  // Insere o pool global se não existir
  db.get(`SELECT COUNT(*) as count FROM pool_global`, (err, row) => {
    if (err) {
      console.error('Erro ao verificar pool:', err);
      return;
    }
    if (row && row.count === 0) {
      db.run(`INSERT INTO pool_global (id, vagas_restantes) VALUES (1, 100)`);
      console.log('✅ Pool global inicializado com 100 vagas');
    }
  });
});

// Função atômica para submeter (coração da solução)
function submeterEntidade(entidadeId, usuarioId, callback) {
  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    // 1. Tenta reservar vaga no pool global
    db.run(`
      UPDATE pool_global 
      SET vagas_restantes = vagas_restantes - 1 
      WHERE id = 1 AND vagas_restantes > 0
    `, function(err) {
      if (err || this.changes === 0) {
        db.run('ROLLBACK');
        return callback({ error: 'POOL_CHEIO' });
      }

      // 2. Tenta reservar cota pessoal
      db.run(`
        UPDATE cota_usuario 
        SET vagas_ativas = vagas_ativas + 1 
        WHERE usuario_id = ? AND vagas_ativas < 2
      `, [usuarioId], function(err) {
        if (err || this.changes === 0) {
          db.run('ROLLBACK');
          return callback({ error: 'COTA_PESSOAL' });
        }

        // 3. Verifica se a entidade existe e pertence ao usuário
        db.get(`
          SELECT id, status FROM entidades 
          WHERE id = ? AND usuario_id = ? AND status = 'RASCUNHO'
        `, [entidadeId, usuarioId], (err, entidade) => {
          if (err || !entidade) {
            db.run('ROLLBACK');
            return callback({ error: 'ENTIDADE_NAO_ENCONTRADA' });
          }

          // 4. Atualiza o status da entidade
          db.run(`
            UPDATE entidades 
            SET status = 'PROCESSANDO' 
            WHERE id = ?
          `, [entidadeId], (err) => {
            if (err) {
              db.run('ROLLBACK');
              return callback({ error: 'ERRO_INTERNO' });
            }

            db.run('COMMIT');
            callback(null, { id: entidadeId, status: 'PROCESSANDO' });
          });
        });
      });
    });
  });
}

// Função para finalizar (devolve vaga ao pool)
function finalizarEntidade(entidadeId, usuarioId, callback) {
  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    // Verifica se a entidade existe e pertence ao usuário
    db.get(`
      SELECT id, status FROM entidades 
      WHERE id = ? AND usuario_id = ? AND status = 'PROCESSANDO'
    `, [entidadeId, usuarioId], (err, entidade) => {
      if (err || !entidade) {
        db.run('ROLLBACK');
        return callback({ error: 'ENTIDADE_NAO_ENCONTRADA' });
      }

      // Devolve vaga ao pool global
      db.run(`
        UPDATE pool_global 
        SET vagas_restantes = vagas_restantes + 1 
        WHERE id = 1
      `);

      // Libera cota do usuário
      db.run(`
        UPDATE cota_usuario 
        SET vagas_ativas = vagas_ativas - 1 
        WHERE usuario_id = ?
      `, [usuarioId]);

      // Atualiza status da entidade
      db.run(`
        UPDATE entidades 
        SET status = 'CONCLUIDO' 
        WHERE id = ?
      `, [entidadeId]);

      db.run('COMMIT');
      callback(null, { id: entidadeId, status: 'CONCLUIDO' });
    });
  });
}

module.exports = { db, submeterEntidade, finalizarEntidade };